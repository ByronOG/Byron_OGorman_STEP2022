#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "input.h"
#include "sorting.h"
#include "playlist.h"

#define LINE_LENGTH 80 //max number of columns per row
#define NUMBER_OF_ROWS 46 //max number of rows

int gl_numSongs=0; //global variable to count number of songs in file

int main(int argc, char *argv[])
{
    FILE *fp;

    srand(time(NULL)); //seed the RNG for later use

    //initalise a 2d charcter array to store songs and artists
    char artist_song_time[NUMBER_OF_ROWS][LINE_LENGTH];

    //check to see if we have an argument
    if (argc > 1){

        if((fp = fopen(argv[1], "r")) == NULL){
            printf("\n%s does not exist or cannot be opened for reading.\n", argv[1]);
            return 1;
        }
        else {
            printf("File given as argument exists. Entering function.\n");

            readSongsFromFile(&fp, artist_song_time);
            fclose(fp);
        }
    }
    else { //no file supplied, try the default
        if ((fp = fopen("C://Users//Byron//CLionProjects//Assignment1//artistes+songs.txt", "r")) == NULL){
            //default file isnt there, read from the keyboard
            printf("\nNo file found.\n");
            printf("Please enter from the keyboard:\n");

            //store user input into a file and send it to readsongsfromfile function
            readSongsFromKeyboard(&fp);
            fp = fopen("artistes+songs_input.txt", "r+");
            readSongsFromFile(&fp, artist_song_time);
            fclose(fp);
        }
        else {
            printf("File found.\nEntering function.\n");
            readSongsFromFile(&fp, artist_song_time);
            fclose(fp);
        }
    }

    //sort the songs...
    insertion_sort(artist_song_time);

    //make a copy of the sorted songs for later use
    char artist_song_time_copy[gl_numSongs][LINE_LENGTH];
    memcpy(artist_song_time_copy, artist_song_time, sizeof(char) * gl_numSongs * LINE_LENGTH);


    //print the sorted songs + artists...
    printer(artist_song_time);

    //generate and print out the playlist
    playlist(artist_song_time_copy);

    return 0;
}
