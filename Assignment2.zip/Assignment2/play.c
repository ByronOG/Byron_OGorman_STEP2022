//
// Created by Byron on 03/05/2021.
//
#include <stdio.h>
#include <string.h>
#include "Initialisation.h"
#include "play.h"

struct player{
    char name[20];
    char colour[10];
    int score;
};

typedef struct player Player;

struct board_state{
    char board[8][8];
    int player_turn;
    int white_score;
    int black_score;
};
typedef struct board_state Board_state;

//these 2 arrays represent the 8 possible directions that a bracketing disk can be found
const int ROW_DIRECTIONS[8]={-1, 1, 0, 0, -1, 1, -1, 1};
const int COL_DIRECTIONS[8]={0, 0, 1, -1, 1, 1, -1, -1};

//set_row converts user input to its corresponding row
int set_row(char move[], int y){
    if(strchr(move,'8'))
        y = 7;
    else if(strchr(move,'7'))
        y = 6;
    else if(strchr(move,'6'))
        y = 5;
    else if(strchr(move,'5'))
        y = 4;
    else if(strchr(move,'4'))
        y = 3;
    else if(strchr(move,'3'))
        y = 2;
    else if(strchr(move,'2'))
        y = 1;
    else  if(strchr(move,'1'))
        y = 0;

    return y;
}

//set_row converts user input to its corresponding col
int set_col(char move[], int x){
    if(strchr(move,'a'))
        x = 0;
    else if(strchr(move,'b'))
        x = 1;
    else if(strchr(move,'c'))
        x = 2;
    else if(strchr(move,'d'))
        x = 3;
    else if(strchr(move,'e'))
        x = 4;
    else if(strchr(move,'f'))
        x = 5;
    else if(strchr(move,'g'))
        x = 6;
    else if(strchr(move,'h'))
        x = 7;
    else if(strchr(move, 'p'))
        x = 8;

    return x;
}

//this prototype gets a move from the user
//if the move is legal and valid, the board is returned with the move completed
Board_state get_move(int player, Board_state board, Player player1, Player player2){
    //print board to console
    print_board(board, player1, player2);

    //set loop conditions (-1 means the input is invalid)
    int row = -1;
    int col = -1;
    if (player == 1){ // if it is black's turn
        while ((row == -1) || (col == -1)){ //get a move until a legal move is entered by the user
            printf("\nIt is Black's turn. Enter your move:");
            char move[4];
            fgets(move, 4, stdin);
            //convert move to its corresponding row and column
            row = set_row(move, row);
            col = set_col(move, col);
            //if move is not legal (letter from a to h, digit from 1 to 8) -> tell user
            if ((row == -1) || (col == -1)){
                printf("\nInvalid move. Enter a letter from a to h then a number from 1-8 (ex. 1d)");
            }
            //if user wants to pass print:
            if (col == 8){
                col = -1; //reset the loop condition to invalid
                printf("\nYou entered p for pass!\n");
                printf("The game will tell you when you have no valid moves remaining!\n");
            }
        }
    }
    else { //else it is white's turn
        while ((row == -1) || (col == -1)){
            printf("\nIt is White's turn. Enter your move:");
            char move[4];
            fgets(move, 4, stdin);
            //convert move to its corresponding row and column
            row = set_row(move, row);
            col = set_col(move, col);
            //if move is not legal (letter from a to h, digit from 1 to 8) -> tell user
            if ((row == -1) || (col == -1)){
                printf("\nInvalid move. Enter a letter from a to h then a number from 1-8 (ex. 1d)");
            }
            //if user wants to pass print:
            if (col == 8){
                col = -1; //reset the loop condition to invalid
                printf("\nYou entered p for pass!\n");
                printf("The game will tell you when you have no valid moves remaining!\n");
            }
        }
    }
    //if the move is valid, make the move
    if (is_valid(row, col, board, player)){
        board = make_move(row, col, board, player);
    }
    //else it is not valid and prompt user to enter a different move
    else {
        board = get_move(player, board, player1, player2);
    }

    return board;
}

//this prototype determines if a player has any valid moves remaining, it is called from next_turn (below)
int game_state(int player, Board_state board){
    int row, col;
    int invalid = 0; //invalid counter set to 0

    //loop through all board positions to see how many invalid moves a player has
    for (row=0;row<8;row++){
        for (col=0;col<8;col++){
            if (!is_valid(row, col, board, player)){ //if the move is invalid, increase counter
                invalid++;
            }
        }
    }
    if (invalid <64){ //if less than 64, the player has atleast 1 valid move
        return 1;
    }
    else { //else the player has no valid moves to make
        return 0;
    }
}

//next_turn determines which turn is next (or if the game is complete)
//it is called from main
Board_state next_turn(Board_state board){
    int opp;
    //opp is the next player's turn
    opp = opponent(board.player_turn);

    // if opp has atleast 1 valid move to make, set player turn to opp
    if (game_state(opp, board)){
        board.player_turn = opp;
        return board;
    }
    //if opp has no valid moves to make, check if current player has atleast one move to make
    if (game_state(board.player_turn, board)){
        if (board.player_turn == 1){ //white has no valid moves to make
            printf("\nWhite has no legal moves and must pass.\n");
        }
        else { //black has no valid moves to make
            printf("\nBlack has no legal moves and must pass.\n");
        }
        return board;
    }
    //there are no valid moves, set player turn to 0 (end the game)
    board.player_turn = 0;
    return board;
}

//this prototype sees if a move is valid
//it is called from game_state and get_move
//it takes a row and col (a move) and checks if it is a valid move
int is_valid(int row, int col, Board_state board, int player){
    int i;
    //if the move is a empty disk
    if (board.board[row][col] == '*'){
        i = 0;
        //while loop that checks the 8 directions that flips can be performed
        while (i<=7 && !would_flip(row, col, player, board, ROW_DIRECTIONS[i], COL_DIRECTIONS[i])){
            i++;
        }
        //if move is not valid
        if (i==8){
            return 0;
        }
        else { //else the move is valid
            return 1;
        }
    }
    else { //else the move is invalid as the disk is occupied
        return 0;
    }
}

//this prototype checks if a disk has a bracketing disk
//it does this by searching a direction from the move, once the move has an opponents' disk adjacent to it in the given direction
//it is called from is_valid (above)
int would_flip(int row, int col, int player, Board_state board, int row_dir, int col_dir){
    int row_move, col_move;
    //move one disk in given direction
    row_move = row + row_dir;
    col_move = col + col_dir;

    //if this disk is the opponents, find the bracketing piece of the disk
    if (player == 1){ //if black's turn
        if (board.board[row_move][col_move] == 'W'){ //if this disk is white
            //return 1 if a bracketing disk is found
            return find_bracketer(row_move+row_dir, col_move+col_dir, player, board, row_dir, col_dir);
        }
        else { // else return 0, no bracketer found
            return 0;
        }
    }
    else { //else it's white's turn
        if (board.board[row_move][col_move] == 'B'){ //if this disk is black
            //return 1 if a bracketing disk is found
            return find_bracketer(row_move+row_dir, col_move+col_dir, player, board, row_dir, col_dir);
        }
        else { // else return 0, no bracketer found
            return 0;
        }
    }
}

//this prototype swaps the turn of the player
int opponent(int player){
    switch (player) {
        case 1: return 2; //if 1 (black's turn) swap to 2 (white)
        case 2: return 1; //if 2 (white's turn) swap to 1 (black)
        default: printf("\nillegal player\n"); return 0; //else it is an error
    }
}

//this prototype checks if a disk has a bracketing disk
// it is called from would_flip (above)
int find_bracketer(int row, int col, int player, Board_state board, int row_dir, int col_dir){
    if (player == 1){ //if black's turn
        //while the disk is white, move along one disk in given direction
        while (board.board[row][col] == 'W'){
            //update row and col
            row = row + row_dir;
            col = col + col_dir;
        }
    }
    else { //else it is white's turn
        //while the disk is black, move along one disk in given direction
        while (board.board[row][col] == 'B'){
            //update row and col
            row = row + row_dir;
            col = col + col_dir;
        }
    }
    if (player == 1){ //if blacks turn look for black piece
        //after the while loop, board.board[row][col] will either be out of bounds, * or B
        //if B, return 1 -> bracketing disk found
        if (board.board[row][col] == 'B'){
            return 1;
        }
        else { //else bracketer not found
            return 0;
        }
    }
    else { // if whites turn look for white piece
        //after the while loop, board.board[row][col] will either be out of bounds, * or W
        //if W, return 1 -> bracketing disk found
        if (board.board[row][col] == 'W'){
            return 1;
        }
        else { //else bracketer not found
            return 0;
        }
    }
}

//this prototype finds the row position of the bracketing disk, if there is one
//it is called from the prototype flip (below)
int find_bracketer_row(int row, int col, int player, Board_state board, int row_dir, int col_dir){
    int found = 0; //set to 1 if a bracketer is found
    //move along 1 disk in given direction
    row = row + row_dir;
    col = col + col_dir;
    if (player == 1){ // if black's turn
        if (board.board[row][col] == 'W'){ //if disk is white
            //loop until not white, board.board[row][col] will either be out of bounds, * or B
            while (board.board[row][col] == 'W'){
                row = row + row_dir;
                col = col + col_dir;
                found = 1; //bracketing disk found
            }

            //after the while loop, board.board[row][col] will either be out of bounds, * or B
            //if B, return row position
            if ((found != 0) && (board.board[row][col] == 'B')){
                return row;
            }
            else { //there is no bracketing disk
                return -1;
            }
        }
        else { //else there is no bracketing disk
            return -1;
        }

    }
    else { //white's turn
        if (board.board[row][col] == 'B'){ //if disk is black
            //loop until not black, board.board[row][col] will either be out of bounds, * or W
            while (board.board[row][col] == 'B'){
                row = row + row_dir;
                col = col + col_dir;
                found = 1; //found bracketer
            }

            //after the while loop, board.board[row][col] will either be out of bounds, * or W
            //if W, return row position
            if ((found != 0) && (board.board[row][col] == 'W')){
                return row;
            }
            else { //else there is no bracketing disk
                return -1;
            }
        }
        else { //else there is no bracketing disk
            return -1;
        }

    }
}

//this prototype finds the col position of the bracketing disk, if there is one
//it is called from the prototype flip (below)
//it is exaclty the same as find_bracketer_row except that it returns the col position instead of row
int find_bracketer_col(int row, int col, int player, Board_state board, int row_dir, int col_dir){
    int found = 0; //set to 1 if a bracketer is found
    //move along 1 disk in given direction
    row = row + row_dir;
    col = col + col_dir;
    if (player == 1){ // if black's turn
        if (board.board[row][col] == 'W'){ //if disk is white
            //loop until not white, board.board[row][col] will either be out of bounds, * or B
            while (board.board[row][col] == 'W'){
                row = row + row_dir;
                col = col + col_dir;
                found = 1; //bracketing disk found
            }

            //after the while loop, board.board[row][col] will either be out of bounds, * or B
            //if B, return col position
            if ((found != 0) && (board.board[row][col] == 'B')){
                return col;
            }
            else { //there is no bracketing disk
                return -1;
            }
        }
        else { //else there is no bracketing disk
            return -1;
        }

    }
    else { //white's turn
        if (board.board[row][col] == 'B'){ //if disk is black
            //loop until not black, board.board[row][col] will either be out of bounds, * or W
            while (board.board[row][col] == 'B'){
                row = row + row_dir;
                col = col + col_dir;
                found = 1; //found bracketer
            }

            //after the while loop, board.board[row][col] will either be out of bounds, * or W
            //if W, return col position
            if ((found != 0) && (board.board[row][col] == 'W')){
                return col;
            }
            else { //else there is no bracketing disk
                return -1;
            }
        }
        else { //else there is no bracketing disk
            return -1;
        }

    }
}

//this prototype makes the move, it flips the 'move' disk and all the eligible disks
//it is called from get_move (above)
Board_state make_move(int row, int col, Board_state board, int player){
    if (player == 1){ //if black's turn
        board.board[row][col] = 'B'; //flip disk to black
    }
    else { //else it is white's turn
        board.board[row][col] = 'W'; //flip disk to white
    }
    //for loop to flip all eligible disks
    //loops 8 times to flip all eligible disks in the 8 possible directions
    for(int i = 0;i<=7; i++){
        board = flip(row, col, board, player, ROW_DIRECTIONS[i], COL_DIRECTIONS[i]);
    }
    return board;
}

//this prototype flips all eligible disks in a given direction
//eligible disks are disks that are between the 'move' disk and the bracketing disk
//it is called from make_move (above)
Board_state flip(int row, int col, Board_state board, int player, int row_dir, int col_dir){

    int row_bracketer, col_bracketer, next_row, next_col;
    //find the bracketing disk
    row_bracketer = find_bracketer_row(row, col, player, board, row_dir, col_dir);
    col_bracketer = find_bracketer_col(row, col, player, board, row_dir, col_dir);

    //if bracketing disk is found
    if ((row_bracketer != -1) && (col_bracketer != -1)){
        next_row = row + row_dir;
        next_col = col + col_dir;
        if (player == 1){ //if its blacks turn, flip disks to black
            //do flips until you reach the bracketing disk
            do {
                board.board[next_row][next_col] = 'B';
                next_row = next_row + row_dir;
                next_col = next_col + col_dir;
            } while ((next_row != row_bracketer) || (next_col != col_bracketer));
        }
        else { // else its whites turn, flip disks to white
            //do flips until you reach the bracketing disk
            do {
                board.board[next_row][next_col] = 'W';
                next_row = next_row + row_dir;
                next_col = next_col + col_dir;
            } while ((next_row != row_bracketer) || (next_col != col_bracketer));
        }
    }
    return board;
}
