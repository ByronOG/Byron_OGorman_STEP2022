//
// Created by Byron on 13/05/2021.
//

#ifndef ASSIGNMENT2_FILE_H
#define ASSIGNMENT2_FILE_H

typedef struct player Player;

typedef struct board_state Board_state;

void upload_record(Board_state board, Player player1, Player player2);

void print_file();

Board_state result(Board_state board, Player player1, Player player2);

#endif //ASSIGNMENT2_FILE_H
