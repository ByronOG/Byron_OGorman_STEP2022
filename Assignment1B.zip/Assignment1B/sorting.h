//
// Created by Byron on 25/03/2021.
//
#include <stdio.h>

#ifndef ASSIGNMENT1B_SORTING_H
#define ASSIGNMENT1B_SORTING_H

#define LINE_LENGTH 80
#define NUMBER_OF_ROWS 46

void insertion_sort(char array[][LINE_LENGTH]);

void printer(char array[][LINE_LENGTH]);

#endif //ASSIGNMENT1B_SORTING_H
