//
// Created by Byron on 13/05/2021.
//

#include "File.h"
#include <stdio.h>
#include <string.h>
#include "Initialisation.h"
#include "play.h"
#include <time.h>

struct player{
    char name[20];
    char colour[10];
    int score;
};

typedef struct player Player;

struct board_state{
    char board[8][8];
    int player_turn;
    int white_score;
    int black_score;
};
typedef struct board_state Board_state;

//this prototype appends the record (game result) to the file othello-results.txt
//if the file does not exist it will be created
void upload_record(Board_state board, Player player1, Player player2){
    FILE *fPtr; //file pointer
    fPtr = fopen("C://Users//Byron//CLionProjects//Assignment2//othello-results.txt", "a");
    if (fPtr == NULL){
        puts("\nFile could not be opened\n");
    }
    else{
        //store the time and date to string s
        char s[30];
        size_t i;
        struct tm tim;
        time_t now;
        now = time(NULL);
        tim = *(localtime(&now));
        i = strftime(s,30,"%b %d, %Y; %H:%M:%S",&tim);
        //print s and the result to the file
        fprintf(fPtr, "%s | Result: %s (Black) %d:%d (White) %s\n", s, player1.name, board.black_score, board.white_score, player2.name);
    }
    fclose(fPtr); //close file
}

//this prototype prints the contents of the file othello-results.txt
void print_file(){
    FILE *fPtr;
    fPtr = fopen("C://Users//Byron//CLionProjects//Assignment2//othello-results.txt", "r+");
    if (fPtr == NULL){
        puts("\nFile could not be opened\n");
    }
    else{
        printf("\n\nHere is the contents for the file othello-results.txt\n\n");
        char str[100]; //var to be used in fgets
        while (fgets(str, 100, fPtr) != NULL) { //loop until EOF is reached
            puts(str);
        }
    }
    fclose(fPtr); //close file
}

//this prototype updates the board with the final result
Board_state result(Board_state board, Player player1, Player player2){
    int i, j;
    //set score to 0 before counting
    player1.score = 0;
    player2.score = 0;

    //count how many tiles each player has
    for(i=0;i<8;i++){
        for(j=0;j<8;j++){
            if (board.board[i][j] == 'B'){
                player1.score++;
            }
            else if (board.board[i][j] == 'W'){
                player2.score++;
            }
        }
    }
    //update score
    board.black_score = player1.score;
    board.white_score = player2.score;
    return board;
}