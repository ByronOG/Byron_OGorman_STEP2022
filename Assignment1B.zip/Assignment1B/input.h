//
// Created by Byron on 25/03/2021.
//
#include <stdio.h>

#ifndef ASSIGNMENT1B_LIBRARY_H
#define ASSIGNMENT1B_LIBRARY_H

#define LINE_LENGTH 80
#define NUMBER_OF_ROWS 46
#define DATA_SIZE 100

void readSongsFromFile(FILE** fp, char array[][LINE_LENGTH]); //check array conds for errors

void readSongsFromKeyboard(FILE** fp);

#endif //ASSIGNMENT1B_LIBRARY_H
