//
// Created by Byron on 25/03/2021.
//

#include "input.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int gl_numSongs;

//function that reads from a file and stores to an array
void readSongsFromFile(FILE** fp, char array[][LINE_LENGTH]){

    int numSongs = 0; //variable used in while loop
    //loop until eof
    while (1) {
        //read first line of file, it will be an artist
        fgets(array[numSongs], LINE_LENGTH, *fp);

        //copy it into var artist
        char artist[30];
        strcpy(artist, array[numSongs]);

        //strip the trailing newline character
        int linelen = strlen(array[numSongs]);
        if(artist[linelen - 1] == '\n'){
            artist[linelen - 1] = '\0';
        }
        //get the next line from the file (song and duration)
        fgets(array[numSongs], LINE_LENGTH, *fp);

        //do while loop to store artist and song together in a 2d array
        do {
            //printf("entered while loop 2\n"); testing

            //use tokens and strncat to store all the info into one row
            char artist_name_song_tmp[LINE_LENGTH];
            char stars[] = "***";
            strcpy(artist_name_song_tmp, artist);
            strncat(artist_name_song_tmp, stars, LINE_LENGTH);
            strncat(artist_name_song_tmp, array[numSongs], LINE_LENGTH);
            strcpy(array[numSongs], artist_name_song_tmp);


            //strip the trailing newline character
            int linelen2 = strlen(array[numSongs]);
            if(array[numSongs][linelen2 - 1] == '\n'){
                array[numSongs][linelen2 - 1] = '\0';
            }

            //increment the global variable and numSongs
            gl_numSongs++;
            numSongs++;

            //get the next line
            fgets(array[numSongs], LINE_LENGTH, *fp);

            //if there is an error, exit, otherwise finish the function
            if ((ferror(*fp))){
                exit(1);
            }
            else if(feof(*fp)){
                return;
            }
        }  while (array[numSongs][0] != '\n');
    }
}

//prototype to store user input into a file
void readSongsFromKeyboard(FILE** fp){
    printf("\nreadSongsFromKeyboard function entered.\n ");
    printf("You must enter 20 lines of data in this function\n");
    printf("Write the artistes and songs to the console EXACTLY as specified in the sample input file.\n");
    printf("Artists are written to the console on their own line.\n");
    printf("Example input for 5 lines of data from the sample file:\n");
    printf("Enter data:\nThe National\n");
    printf("Enter data:\nEngland***5:40\n");
    printf("Enter data:\n(Enter)\n");
    printf("Enter data:\nArcade Fire\n");
    printf("Enter data:\nWake Up***5:39\n");

    *fp = fopen("artistes+songs_input.txt", "w");

    int i=0;
    //loop until 20 lines of input is inputted
    while (i<20){
        //prompt user to input
        printf("Enter data:\n");
        char data[DATA_SIZE];

        //store input in data
        fgets(data, DATA_SIZE, stdin);

        /* Write data to file */
        fputs(data, *fp);
        i++;
    }

    /* Close file to save file data */
    fclose(*fp);

    /* Success message */
    printf("\n\nFile created and saved successfully. :) \n");

}