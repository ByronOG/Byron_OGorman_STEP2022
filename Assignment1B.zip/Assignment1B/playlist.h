//
// Created by Byron on 26/03/2021.
//
#include <stdio.h>

#ifndef ASSIGNMENT1B_PLAYLIST_H
#define ASSIGNMENT1B_PLAYLIST_H

#define LINE_LENGTH 80
#define NUMBER_OF_ROWS 46

void fydkShuffle1(int arr[], int arr2[], int size);

void convert(int seconds);

void playlist(char arr[][LINE_LENGTH]);


#endif //ASSIGNMENT1B_PLAYLIST_H
