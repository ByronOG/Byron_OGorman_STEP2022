//
// Created by Byron on 25/03/2021.
//

#include "sorting.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int gl_numSongs;

//prototype to sort the array of artists and songs using insertion sort
void insertion_sort(char artist_song_time[][LINE_LENGTH]){
    //declare some variables
    int i, j;
    char val[LINE_LENGTH];

    for(i=1; i<gl_numSongs; i++){
        /*Start at i = 1, the first one is sorted.  */
        j = i;
        strcpy(val, artist_song_time[j]);
        while (j > 0 && strcmp(val, artist_song_time[j - 1]) < 0){
            /*shuffle the items that are bigger than val along by one...*/
            strcpy(artist_song_time[j], artist_song_time[j - 1]);
            j--;
        }
        /*insert the item into its correct position.*/
        strcpy(artist_song_time[j], val);
    }
}

//prototype to print the sorted array according to the specifications
void printer(char artist_song_time[][LINE_LENGTH]){
    printf("\nSorted list of artists and songs:\n");

    //initialise previous artist
    char prevArtist[30];
    strcpy(prevArtist, artist_song_time[0]);

    //declare some variables
    const char delim[] = "***";
    char *token;

    for(int i=0;i<gl_numSongs;i++){

        //declare the variables to store our tokens
        char currentArtist[30], song[50], duration[8];

        /*  Extract the first token (current artist)  */
        token = strtok(artist_song_time[i], delim);
        strcpy(currentArtist, token);

        /*  Extract the next token (song)  */
        token = strtok(NULL, delim);
        strcpy(song, token);

        /*  Extract the next token (duration)  */
        token = strtok(NULL, delim);
        strcpy(duration, token);

        //check if current artist is == to prev artist
        if (strcmp(currentArtist, prevArtist) != 0){
            //update prev artist
            strcpy(prevArtist, currentArtist);
            //print according to specifications
            printf("\n");
            printf("%s\n", currentArtist);
        }
        //print according to specifications
        printf("\t o %s***%s\n", song, duration);
    }
}
