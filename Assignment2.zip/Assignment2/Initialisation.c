//
// Created by Byron on 16/04/2021.
//
#include <stdio.h>
#include <string.h>
#include "Initialisation.h"

struct player{
    char name[20];
    char colour[10];
    int score;

};

typedef struct player Player;

struct board_state{
    char board[8][8];
    int player_turn;
    int white_score;
    int black_score;
};
typedef struct board_state Board_state;

//startGame initialises player1 (black)
Player startGame(Player player){
    printf("*** Welcome to Othello! ***");
    printf("\n\nEnter name of Player 1 (Black):");
    fgets(player.name, 20, stdin);

    //strip the newline character
    if (player.name[strlen(player.name) - 1] == '\n'){
        player.name[strlen(player.name) - 1] = '\0';
    }
    //assign colour
    strcpy(player.colour, "Black");
    player.score = 2;

    return player;
}

//startGame initialises player2 (white)
Player startGame2(Player player){
    printf("\n\nEnter name of Player 2 (White):");
    fgets(player.name, 20, stdin);

    //strip the newline character
    if (player.name[strlen(player.name) - 1] == '\n'){
        player.name[strlen(player.name) - 1] = '\0';
    }
    //assign colour
    strcpy(player.colour, "White");
    player.score = 2;

    return player;
}

//init_board initialises the board's components
Board_state init_board(Board_state board){
    int i, j;
    //initialise empty board (* = unassigned disk)
    for(i=0;i<8;i++){
        for(j=0;j<8;j++){
            board.board[i][j] = '*';
        }
    }

    //initialise the central pieces
    board.board[3][3] = 'W';
    board.board[4][4] = 'W';
    board.board[3][4] = 'B';
    board.board[4][3] = 'B';

    //set player turn to black
    board.player_turn = 1; //1 is black 2 is white 0 is game over

    return board;
}

//print_board prints the board and the current score
void print_board(Board_state board, Player player1, Player player2){
    int i, j;
    player1.score = 0;
    player2.score = 0;

    //count how many tiles each player has
    for(i=0;i<8;i++){
        for(j=0;j<8;j++){
            if (board.board[i][j] == 'B'){
                player1.score++;
            }
            else if (board.board[i][j] == 'W'){
                player2.score++;
            }
        }
    }

    //print the board and the score
    printf("\nScore: %s (%s) %d:%d (%s) %s \n", player1.name, player1.colour, player1.score, player2.score, player2.colour, player2.name);
    for(i=0;i<8;i++){
        printf("\n   --- --- --- --- --- --- --- --- ");
        printf("\n%d |", i+1);
        for(j=0;j<8;j++){
            if (board.board[i][j] == '*'){
                printf("   |");
            }
            else{
                printf(" %c |", board.board[i][j]);
            }
        }
    }
    printf("\n   --- --- --- --- --- --- --- --- ");
    printf("\n    a   b   c   d   e   f   g   h   ");
}
