#include <stdio.h>
#include "Initialisation.h"
#include "play.h"
#include "File.h"

//struct to hold player information
struct player{
    char name[20];
    char colour[10];
    int score;
};

//struct contains the board state
struct board_state{
    char board[8][8];
    int player_turn; // 1 is black, 2 is white
    int white_score;
    int black_score;
};

typedef struct player Player;

typedef struct board_state Board_state;

/* Terminology used:
 * bracketer = short for 'bracketing disk'
 * flip = to flip a disk's colour (b -> w and w -> b)
 * move = the position on the board that a player wants to place a disk on
 * */

int main() {
    //initialize the players
    Player player1 = startGame(player1);
    Player player2 = startGame2(player2);

    //initialize the board
    Board_state board = init_board(board);

    //play the game
    do {
        if (board.player_turn == 1) { //if it is blacks turn
            //make their move
            board = get_move(1, board, player1, player2);

        }
        else { // else it is whites turn
            //make their move
            board = get_move(2, board, player1, player2);
        }
        //change turn, if no moves left -> end game
        board = next_turn(board);
    }
    while (board.player_turn != 0); //while the game is not over

    //print result to console
    printf("\n\nThe game is over!\nHere is the result:\n");
    print_board(board, player1, player2);

    //upload result to a file
    board = result(board, player1, player2);
    upload_record(board, player1, player2);

    //print file to user
    print_file();
    return 0;
}
