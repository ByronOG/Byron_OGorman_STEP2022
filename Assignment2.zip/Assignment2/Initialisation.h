//
// Created by Byron on 16/04/2021.
//

#ifndef ASSIGNMENT2_INITIALISATION_H
#define ASSIGNMENT2_INITIALISATION_H

typedef struct player Player;

typedef struct board_state Board_state;

Player startGame(Player player);

Player startGame2(Player player);

Board_state init_board(Board_state board);

void print_board(Board_state board, Player player1, Player player2);

#endif //ASSIGNMENT2_INITIALISATION_H
