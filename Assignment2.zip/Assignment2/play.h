//
// Created by Byron on 03/05/2021.
//

#ifndef ASSIGNMENT2_PLAY_H
#define ASSIGNMENT2_PLAY_H

typedef struct player Player;

typedef struct board_state Board_state;

int set_row(char move[], int y);

int set_col(char move[], int x);

Board_state get_move(int player, Board_state board, Player player1, Player player2);

int game_state(int player, Board_state board);

Board_state next_turn(Board_state board);

int is_valid(int row, int col, Board_state board, int player);

Board_state make_move(int row, int col, Board_state board, int player);

Board_state flip(int row, int col, Board_state board, int player, int row_dir, int col_dir);

int would_flip(int row, int col, int player, Board_state board, int row_dir, int col_dir);

int opponent(int player);

int find_bracketer(int row, int col, int player, Board_state board, int row_dir, int col_dir);

int find_bracketer_row(int row, int col, int player, Board_state board, int row_dir, int col_dir);

int find_bracketer_col(int row, int col, int player, Board_state board, int row_dir, int col_dir);

#endif //ASSIGNMENT2_PLAY_H
