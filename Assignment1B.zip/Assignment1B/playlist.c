//
// Created by Byron on 26/03/2021.
//

#include "playlist.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int gl_numSongs;


//Shuffle an array of ints using the Fisher-Yates Durstenfeld Knuth Shuffle algorithm.(inside out method)
void fydkShuffle1(int arr[], int arr2[], int size)
{
    int i, j;

    for (i = 0;  i < size;  i++)
    {
        j = rand() % (i + 1);
        if (j != i){
            arr[i] = arr[j];
        }
        arr[j] = arr2[i];
    }
}

//prototype to convert total seconds to hours+minutes. Then prints it
void convert(int seconds){

    int h, m, s;
    h = (seconds/3600); //decimal division, returns an int
    m = (seconds -(3600*h)) / 60; //decimal division, returns an int
    s = (seconds -(3600*h)-(m*60)); //decimal division, returns an int

    printf("\nTotal duration: %d:%d:%d\n", h, m, s);
}

void playlist(char array[][LINE_LENGTH]){
    int arr[gl_numSongs], source[gl_numSongs], i;

    /*  Initialise the arrays.  */
    for (i = 0;  i < gl_numSongs;  i++) {
        arr[i] = i;
    }
    for (i=0;i<gl_numSongs;i++){
        source[i] = i;
    }

    //shuffle the array
    fydkShuffle1(arr, source, gl_numSongs);

    printf("\nRandomised Playlist:\n");

    //loop conditions
    i=0;
    int totalSeconds = 0;

    //declare some variables
    char currentArtist[50], prevArtist[50], prevprevArtist[50];
    char *token;
    const char delim[] = "***";
    const char delim2[] = ":";

    //loop until there's no more songs or the playlist is an hour long (ie starts before it reaches an hour long)
    while ((i < gl_numSongs) && (totalSeconds < 3600)){
        //store prev artist to prevprevartist
        strcpy(prevprevArtist, prevArtist);
        //store current artist to prev artist
        strcpy(prevArtist, currentArtist);

        /*  Extract the first token (current artist)  */
        token = strtok(array[arr[i]], delim);
        strcpy(currentArtist, token);

        //if the previous 2 songs were from the same artist, skip it
        if( (strcmp(currentArtist, prevArtist) == 0) && (strcmp(currentArtist, prevprevArtist) == 0)){

        }

        else {
            char song[LINE_LENGTH], duration[8];

            /*  Extract the next token (song)  */
            token = strtok(NULL, delim);
            strcpy(song, token);

            /*  Extract the next token (duration)  */
            token = strtok(NULL, delim);
            strcpy(duration, token);


            char minutes[4], seconds[3];

            /*  Extract the first token of duration (minutes)*/
            token = strtok(duration, delim2);
            strcpy(minutes, token);

            //change minutes to seconds and add to totalSeconds
            int x = atoi(minutes);
            x = x*60;
            totalSeconds += x;

            /*  Extract the second token of duration (seconds)*/
            token = strtok(NULL, delim2);
            strcpy(seconds, token);

            //add the remaining seconds to totalSeconds
            x = atoi(seconds);
            totalSeconds += x;

            //print to console according to specs
            printf("%s: \"%s\" (%s:%s)\n", currentArtist, song, minutes, seconds);
        }
        i++; //increment i on each iteration
    }
    convert(totalSeconds);
}

